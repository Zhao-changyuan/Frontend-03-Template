let a = 6;

for (let i of [1, 2, 3, 4, 5 ]) {
      console.log(a, i);
}

let b;